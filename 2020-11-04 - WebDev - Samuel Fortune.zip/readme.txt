the landing page simply redirects to the /cars page.
/cars/new (which can be accessed by clicking "Add Car") allows the user to add cars to the database.
If any of the fields is left empty, the car is not added to the database.
>>> this means all fields must have a value for the car to be added.

Heroku deployment:
https://calm-refuge-82759.herokuapp.com